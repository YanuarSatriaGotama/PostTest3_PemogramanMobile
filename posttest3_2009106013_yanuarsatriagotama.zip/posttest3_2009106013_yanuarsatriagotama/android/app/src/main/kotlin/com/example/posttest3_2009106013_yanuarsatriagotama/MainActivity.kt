package com.example.posttest3_2009106013_yanuarsatriagotama

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
