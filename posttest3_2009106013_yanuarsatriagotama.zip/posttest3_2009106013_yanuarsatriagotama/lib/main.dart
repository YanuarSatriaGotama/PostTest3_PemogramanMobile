import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Post Test 3",
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int angka = 0;
  String nama = " ", barang = "", jumlah = "";
  TextEditingController controllerA = TextEditingController();
  TextEditingController controllerB = TextEditingController();
  TextEditingController controllerC = TextEditingController();
  bool? myCheck = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Toko Elektronik by Yanuar Satria Gotama"),
      ),
      backgroundColor: Color.fromARGB(255, 105, 245, 243),
      body: ListView(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                width: 200,
                height: 250,
                margin: EdgeInsets.only(top: 61),
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage("assets/elec.png"),
                  ),
                ),
              ),
              Text(
                "Form Pembelian\n",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Color.fromARGB(255, 0, 0, 0),
                ),
              ),
            ]
          ),
            
          SizedBox(height:  30),
          TextFormField(
            controller: controllerA,
            decoration: InputDecoration(
              labelText: "Masukkan Nama Anda",
              icon: Icon(Icons.people),
              border: OutlineInputBorder(),
            ),
          ),
          SizedBox(height:  30),
          TextFormField(
            controller: controllerB,
            decoration: InputDecoration(
              labelText: "Masukkan Barang Belanjaan",
              icon: Icon(Icons.shopping_cart),
              border: OutlineInputBorder(),
            ),
          ),
          SizedBox(height: 30),
          TextFormField(
            controller: controllerC,
            decoration: InputDecoration(
              labelText: "Masukkan Jumlah Barang",
              icon: Icon(Icons.shopping_bag),
              border: OutlineInputBorder(),
            ),
          ),
          SizedBox(height: 30),
          ElevatedButton(
            onPressed: () {
              setState(() {
                nama = controllerA.text;
                barang = controllerB.text;
                jumlah = controllerC.text;
              });
            }, 
          child: Text("Submit"),
          ),
          Text("Apakah yang Anda masukkan sudah benar?"),
          Checkbox(value: myCheck, onChanged: (value) {
            myCheck = value ;
            setState(() {});
          }),
          Text("\t\tNama Anda : $nama \n \t\tBarang Belanjaan :  $barang \n \t\tJumlah Barang : $jumlah \n Terima Kasih Pesanan Anada akan Kami Proses")
          ],
        ),
    );
  }
}